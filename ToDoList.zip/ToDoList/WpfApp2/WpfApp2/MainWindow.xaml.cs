﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace TodoApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<TaskItem> Tasks { get; set; }

        private TaskItem _editingTask;

        public MainWindow()
        {
            InitializeComponent();
            Tasks = new ObservableCollection<TaskItem>();
            taskList.ItemsSource = Tasks; 
        }

        private void AddUpdateTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(taskInput.Text) || dueDatePicker.SelectedDate == null)
                return;

            string priority = (priorityComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (_editingTask != null)
            {
                _editingTask.TaskName = taskInput.Text;
                _editingTask.DueDate = dueDatePicker.SelectedDate.Value;
                _editingTask.Priority = priority;

                _editingTask = null;
                addUpdateButton.Content = "Add Task";
            }
            else
            {
                Tasks.Add(new TaskItem
                {
                    TaskName = taskInput.Text,
                    IsCompleted = false,
                    DueDate = dueDatePicker.SelectedDate.Value,
                    Priority = priority
                });
            }

            taskInput.Clear();
            dueDatePicker.SelectedDate = null;
            priorityComboBox.SelectedIndex = 0;
        }

        private void EditTask_Click(object sender, RoutedEventArgs e)
        {
            if (taskList.SelectedItem is TaskItem task)
            {
                _editingTask = task;
                taskInput.Text = _editingTask.TaskName;
                dueDatePicker.SelectedDate = _editingTask.DueDate;

                priorityComboBox.SelectedIndex = priorityComboBox.Items.IndexOf(
                    priorityComboBox.Items.Cast<ComboBoxItem>().FirstOrDefault(i => i.Content.ToString() == _editingTask.Priority));

                addUpdateButton.Content = "Update Task";
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (taskList.SelectedItem is TaskItem task)
            {
                Tasks.Remove(task);
            }
        }
    }

    public class TaskItem
    {
        public string TaskName { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime DueDate { get; set; }
        public string Priority { get; set; }
    }
}